# Results: latent dimensions of epigenetic variation

## Data and scope

The analysis contains **4 epigenomes** and **30,966 genomic-window features**.

The matrix contains Roadmap signals on a shared genomic grid, log-transformed and standardized per feature. See `sample_metadata.csv` and `source_manifest.csv` for labels and queried source URLs/settings. Downloaded runs also include SHA-256 records in `data/raw/download_manifest.csv`.

Remote bins use approximate means from Roadmap's precomputed zoom summaries.

## Variance captured

The first three components explain 100.0% of variance in this matrix. The participation-ratio effective dimension is 2.00. The relative reconstruction error is 0.582 at rank 1 and 0.343 at rank 2 and 3.18e-14 at rank 3; the full retained-rank error is 3.18e-14.

- PC1: 66.2% (cumulative 66.2%).
- PC2: 22.1% (cumulative 88.3%).
- PC3: 11.7% (cumulative 100.0%).

With 4 samples, centering limits the rank to at most 3; the near-zero rank-3 error is therefore expected and does not establish biological low dimensionality. Treat the first one or two PCs as exploratory.

Among these samples and marks, the first three dominant patterns summarize the stated share of feature variation. This describes the selected dataset, not every human epigenome.

## Metadata associations

The reported $\eta^2$ is the fraction of a component's score variation lying between metadata categories. Singleton categories are flagged as saturated and omitted from interpretation. Any other association is descriptive, not causal; labels may be confounded with study or assay batch.

No metadata association is estimable: each tested label was unique per sample, which would make $\eta^2=1$ by construction. Replicated samples per category are needed.

## Major features

Largest absolute loadings identify windows most aligned with each component. Both signs matter, and a component's sign is arbitrary. Window associations do not by themselves identify a regulatory mechanism or biological function.

- PC1: `H3K4me3|chr6:18790673-18890623` (loading +0.0070).
- PC1: `H3K4me3|chr13:65982742-66082716` (loading +0.0070).
- PC1: `H3K4me3|chr13:93675499-93775473` (loading +0.0070).
- PC1: `H3K4me3|chr18:2599242-2699213` (loading -0.0070).
- PC1: `H3K4me3|chr3:29888292-29988252` (loading +0.0070).
- PC2: `H3K4me3|chr12:26190587-26290551` (loading +0.0121).
- PC2: `H3K4me3|chr20:2097521-2197403` (loading +0.0121).
- PC2: `H3K4me3|chr3:129349330-129449291` (loading +0.0121).
- PC2: `H3K4me3|chr17:48297150-48397144` (loading +0.0121).
- PC2: `H3K4me3|chr18:21693678-21793649` (loading +0.0121).
- PC3: `H3K4me3|chr2:30399921-30499921` (loading +0.0166).
- PC3: `H3K4me3|chr7:63275611-63375573` (loading -0.0166).
- PC3: `H3K4me3|chr14:70466876-70566829` (loading -0.0165).
- PC3: `H3K4me3|chr12:94566013-94665978` (loading -0.0165).
- PC3: `H3K4me3|chr12:123055775-123155739` (loading -0.0165).

## Numerical cross-check

Covariance-eigenvalue and direct-SVD implementations were checked against scikit-learn by comparing retained eigenvalues. Loading signs may differ because an eigenvector and its negative describe the same axis. See `diagnostics.json`.

## Interpretation and limitations

PCA is linear and prioritizes total variance, not biological importance. Results depend on samples, mark, window size, transform, and standardization. BigWig gaps are treated as zero signal. Batch effects, cell composition, and biological heterogeneity can dominate a component. Standardization gives each retained feature equal variance and can amplify noisy low-signal windows. Components do not establish causation, and dimensionality reduction discards information.

## Figures and reproducibility

Figures are in `figures/`. Run `python -m epigenomics_pca all` to rediscover tracks, download the configured subset, process tracks, recompute this report, and regenerate figures. Retrieval date, URL, byte count, and SHA-256 for each track are in the manifest. Use the `remote` command for approximate zoom summaries without full-track downloads.
